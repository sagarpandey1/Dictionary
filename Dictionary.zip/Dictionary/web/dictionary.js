/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


$(function () {
    $("#btnLookup").click(search);
    //works if enter key is pressed in the text box
    $("#inputWord").keypress(function(e){
        if(e.which==13){
          $("#btnLookup").click();  
        }
    });
    function search() {
        $.ajax('DictionaryServlet', {
            'type': 'post',
            'data': {"lookupitem": $("#inputWord").val()}

        }).done(successMethod).fail(failMethod);
    }

});

function successMethod(data) {
    $("#word").css({"color":"orange","font-size":"24pt"}).html('<h3>' + data.word+":" + '</h3>');
    console.log(data.wordtype.length);
    var list = $("<ol>");
    $("#result").empty();
    $("#result").append(list);
    for (i = 0; i < data.wordtype.length; i++) {
        $("#result").find("ol").append('<li>' + "(" + data.wordtype[i] + ") " + data.definition[i] + '</li>');
    }
    console.log(data);
}


function failMethod() {
    $("#result").empty();
    $("#word").html('<h3 style="color:red">No Word  Found</h3>');
}