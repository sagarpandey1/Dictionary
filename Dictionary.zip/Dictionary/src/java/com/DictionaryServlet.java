/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com;

import java.io.IOException;
import java.io.PrintWriter;

import java.sql.Connection;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

/**
 *
 * @author Madan201
 */
//@WebServlet(name = "DictionaryServlet", urlPatterns = {"/dictionary"})
public class DictionaryServlet extends HttpServlet {
    
    Connection conn = null;
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String inputText = request.getParameter("lookupitem");
        JSONObject obj = new JSONObject();
        JSONArray arrWordType = new JSONArray();
        JSONArray arrDef = new JSONArray();
        int countWord = 0;
        
        try {
            Connection con = DBConnection.connect();
            Statement stmt = null;
            ResultSet rs = null;
            stmt = con.createStatement();
            rs = stmt.executeQuery("select *from entries where word='" + inputText + "'");
            
            while (rs.next()) {
                String word = rs.getString("word");
                countWord++;
                if (countWord == 1) // System.out.println(name);
                {
                    obj.put("word", word);
                }
                String wordtype = rs.getString("wordtype");
                arrWordType.add(wordtype);
                
                String definition = rs.getString("definition");
                arrDef.add(definition);
            }
            obj.put("wordtype", arrWordType);
            obj.put("definition", arrDef);
            //Test output to console
            System.out.println(obj.get("word"));
            System.out.println(obj.get("wordtype"));
            System.out.println(obj.get("definition"));
            rs.close();
            con.close();
        } catch (SQLException ex) {
            Logger.getLogger(DictionaryServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
        try(PrintWriter out = response.getWriter()){
        response.setContentType("text/json;charset=UTF-8");
        out.print(obj);
        }
    }
    
}
