/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author Madan201
 */
public class DBConnection {

   // String dburl = "jdbc:mysql://localhost:3306/entries";
    static Connection con;

   
    
    public static Connection connect() throws SQLException{
     try {
         String Dburl="jdbc:mysql://localhost:3306/entries";
         String user="keith";
         String pw="mumsql";
            Class.forName("com.mysql.jdbc.Driver");
            con=DriverManager.getConnection(Dburl,user, pw);
        } catch (ClassNotFoundException ex) {
            System.out.println("MySQL JDBC driver not found in DBConnection\n" + ex);
            System.exit(0);
        }
    return con;
}  
}
